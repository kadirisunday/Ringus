<?php
session_start();

include(".././config/connection.php");

include("./incl/header.php");

?>

<div class="container-fluid">


    <div class="row g-4">
        <div class="col-12">
            <div class="text-center mx-auto" style="max-width: 700px;">
                <h2 class="display-5">Welcome home <?php echo $_SESSION['username']; ?></h2>
            </div>
        </div>

        <div class="col-lg-2 rounded bg-light">

            <?php include("incl/sidebar.php"); ?>

        </div>
        <div class="col-lg-8">

        </div>

    </div>


</div>




<?php include("incl/footer.php"); ?>