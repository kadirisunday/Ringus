<div class="col-md-6 col-lg-12 featurs-item p-2">


    <h5><a href="./dashboard.php" class="my-auto">Dashboard</a></h5>



</div>
<div class="col-md-6 col-lg-12 featurs-item p-2">



    <h5><a href="./budget.php" class="my-auto">Budget Calculator</a></h5>

</div>
<div class="col-md-4 col-lg-12 featurs-item p-2">


    <h5><a href="./checklist.php" class="my-auto">Wedding Checklist</a></h5>


</div>
<div class="col-md-6 col-lg-12 featurs-item p-2">



    <h5><a href="#" class="my-auto">Save The Date</a></h5>


</div>
<div class="col-md-6 col-lg-12 featurs-item p-2">


    <h5><a href="./vendors.php" class="my-auto">Vendors</a></h5>



</div>
<div class="col-md-6 col-lg-12 featurs-item p-2">


    <h5><a href="./vendors.php" class="my-auto">Saved Vendors</a></h5>



</div>
<div class="col-md-6 col-lg-12 featurs-item p-2">


    <h5><a href="./vendors.php" class="my-auto">Edit Profile</a></h5>



</div>
<div class="col-md-6 col-lg-12 featurs-item p-2">


    <h5><a href="./vendors.php" class="my-auto">Logout</a></h5>



</div>