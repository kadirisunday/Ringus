<?php

$server = "localhost";
$username = "ringvjwq_appring";
$password = "-s=%Y}Lo4L#=";
$db = "ringvjwq_appring";

$conn = new mysqli($server, $username, $password, $db);
