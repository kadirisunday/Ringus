<?php

$server = "localhost";
$username = "root";
$password = "";
$db = "ringus";

$conn = new mysqli($server, $username, $password, $db);
